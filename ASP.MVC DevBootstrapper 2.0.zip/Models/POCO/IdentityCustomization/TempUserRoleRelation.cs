﻿namespace $safeprojectname$.Models.POCO.IdentityCustomization {
    public class TempUserRoleRelation {
        public long TempUserRoleRelationID { get; set; }
        public long UserID { get; set; }
        public long UserRoleID { get; set; }
    }
}