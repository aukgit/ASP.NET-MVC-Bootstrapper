﻿namespace $safeprojectname$.Modules.Cookie {
    public struct CookiesNames {
        public const string Time = "TodayTime";
        public const string ZoneInfo = "ZoneInfo";
        public const string UserId = "UserID";
    }
}