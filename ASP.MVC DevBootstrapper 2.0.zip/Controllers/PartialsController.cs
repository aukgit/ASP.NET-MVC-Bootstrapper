﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Controllers;
using $safeprojectname$.Models.Context;
using $safeprojectname$.Models.EntityModel.POCO;
using DevTrends.MvcDonutCaching;

namespace $safeprojectname$.Controllers
{
    [OutputCache(CacheProfile = "YearNoParam")]
    public class PartialsController : GenericController<DevIdentityDbContext> {
        
        
		#region Constructors

        public PartialsController()
            : base(true) {
	
		} 

		#endregion

 
    }
	
}
