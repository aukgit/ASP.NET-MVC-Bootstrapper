﻿namespace $safeprojectname$.Models.POCO.IdentityCustomization {
    public class CountryTimezoneRelation {
        public int CountryTimezoneRelationID { get; set; }
        public int UserTimeZoneID { get; set; }
        public int CountryID { get; set; }
    }
}